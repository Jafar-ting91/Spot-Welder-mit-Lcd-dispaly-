#pragma once
/*
  Config.h – Zentrale UI/Hardware/Regler-Konfiguration.
  Alles hier änderbar: Kachel-Geometrien, Fonts & Größen pro Kachel,
  Text-Offsets, Farben, Kopfzeile, Stoppuhr, Kalibrierungen, Regler, Pins.

  Hinweis: Für FreeFonts gilt: setTextSize() skaliert die GFX-Fonts integer (1,2,3…).
*/

#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>

// ===================== Skalierung (160x128 -> 320x240) =====================
namespace CFG {
  inline constexpr float SCALE_X = 2.0f;
  inline constexpr float SCALE_Y = 1.875f;
  inline int SX(int x){ return (int)lroundf(x*SCALE_X); }
  inline int SY(int y){ return (int)lroundf(y*SCALE_Y); }
  inline int SW(int w){ return (int)lroundf(w*SCALE_X); }
  inline int SH(int h){ return (int)lroundf(h*SCALE_Y); }
}

// ===================== Farben =====================
namespace CFG::COL {
  inline constexpr uint16_t BLACK   = ILI9341_BLACK;
  inline constexpr uint16_t WHITE   = ILI9341_WHITE;
  inline constexpr uint16_t RED     = ILI9341_RED;
  inline constexpr uint16_t GREEN   = ILI9341_GREEN;
  inline constexpr uint16_t BLUE    = ILI9341_BLUE;
  inline constexpr uint16_t YELLOW  = ILI9341_YELLOW;
  inline constexpr uint16_t ORANGE  = 0xFD20;
  inline constexpr uint16_t DKGRAY  = 0x7BEF;
  inline constexpr uint16_t PURPLE  = 0x780F;
  inline constexpr uint16_t AUTO_TEAL       = 0x136E;
  inline constexpr uint16_t P1_GREEN        = 0x13C6;
  inline constexpr uint16_t SETTINGS_PURPLE = 0x6816;
}

// === Alte Makro-Namen (Kompatibilität) -> Farben aus CFG::COL ===
#define ST77XX_BLACK            CFG::COL::BLACK
#define ST77XX_WHITE            CFG::COL::WHITE
#define ST77XX_RED              CFG::COL::RED
#define ST77XX_GREEN            CFG::COL::GREEN
#define ST77XX_BLUE             CFG::COL::BLUE
#define ST77XX_YELLOW           CFG::COL::YELLOW
#define ST77XX_ORANGE           CFG::COL::ORANGE
#define ST77XX_DARKGREY         CFG::COL::DKGRAY
#define ST77XX_PURPLE           CFG::COL::PURPLE
#define ST77XX_AUTO_TEAL        CFG::COL::AUTO_TEAL
#define ST77XX_P1_GREEN         CFG::COL::P1_GREEN
#define ST77XX_SETTINGS_PURPLE  CFG::COL::SETTINGS_PURPLE

// ===================== Hardware / Pins =====================
namespace CFG::PIN {
  inline constexpr uint8_t MOSFET      = PB8;
  inline constexpr uint8_t TFT_CS      = PA10;
  inline constexpr uint8_t TFT_RST     = PA9;
  inline constexpr uint8_t TFT_DC      = PA8;
  inline constexpr uint8_t ENC_A       = PB13;
  inline constexpr uint8_t ENC_B       = PB14;
  inline constexpr uint8_t ENC_BTN     = PB15;
  inline constexpr uint8_t TRIG_HAND   = PB4;
  inline constexpr uint8_t TRIG_AUTO   = PB12;
  inline constexpr uint8_t PULSE       = PB9;
  inline constexpr uint8_t CAP1        = PA0;
  inline constexpr uint8_t CAP2        = PA1;
  inline constexpr uint8_t TEMP1       = PA3;
  inline constexpr uint8_t TEMP2       = PA4;
  inline constexpr uint8_t BAL_C1      = PB1;
  inline constexpr uint8_t BAL_C2      = PB5;
  inline constexpr uint8_t FAN         = PB0;
}

// ===================== Kalibrierung / Shunt / ADC =====================
namespace CFG::CAL {
  inline constexpr float DIV_R1 = 22000.0f;
  inline constexpr float DIV_R2 = 10000.0f;
  inline constexpr float V_CAL_CAP1 = 1.0015f;
  inline constexpr float V_CAL_CAP2 = 1.0015f;

  inline constexpr float R_SHUNT_OHM = 0.0050f;
  inline constexpr float I_OFFSET_MV_DEFAULT = 0.80f;
  inline constexpr float I_GAIN_DEFAULT      = 0.820f;

  inline constexpr int   ADC_AVG_N        = 24;
  inline constexpr int   ADC_AVG_DELAY_US = 75;
}

// ===================== Regler / PWM / Rampen =====================
namespace CFG::CTRL {
  inline constexpr int PWM_TOP = 4500;                 // 16 kHz @ 72 MHz
  inline constexpr uint16_t DUTY_MIN = 0;
  inline constexpr uint16_t DUTY_MAX = PWM_TOP;

  inline constexpr float Kp_counts_per_A   = 30.0f;
  inline constexpr float Ki_counts_per_A_s = 0.50f;

  inline constexpr uint16_t PERIOD_MS      = 30;
  inline constexpr float    TAU_I_FILTER_S = 0.15f;

  inline constexpr float IINT_LIMIT_FRAC   = 0.6f;

  inline constexpr float RAMP_THRESH_FRAC  = 0.70f;
  inline constexpr float RAMP_FAST_A_S     = 2.0f;
  inline constexpr float RAMP_SLOW_A_S     = 0.5f;
  inline constexpr float RAMP_DOWN_A_S     = 25.0f;

  inline constexpr float DUTY_FAST_PCT_S   = 70.0f;
  inline constexpr float DUTY_SLOW_PCT_S   = 25.0f;
}

// ===================== Betriebs-Limits / Hysterese =====================
namespace CFG::LIM {
  inline constexpr float CAP_V_MIN_DEF  = 2.0f;
  inline constexpr float CAP_V_MAX_DEF  = 4.2f;
  inline constexpr float TEMP_WARN_DEF  = 60.0f;
  inline constexpr float FAN_ON_C       = 55.0f;
  inline constexpr float FAN_OFF_C      = 40.0f;

  inline constexpr float OV_EPS_V       = 0.005f;
  inline constexpr float RESUME_HYST_DEF= 0.10f;
}

// ===================== Auto/Timing/Weld-V =====================
namespace CFG::WELD {
  inline constexpr float ZIELSTROM_DEF      = 2.0f;
  inline constexpr float ZIELLEISTUNG_W_DEF = 20.0f;
  inline constexpr float AUTOPULSE_DELAY_S  = 0.5f;
  inline constexpr float STARTBTN_DELAY_S   = 0.0f;

  inline constexpr float WELD_V_DEFAULT     = 8.40f; // wird auf 2*min..2*max begrenzt
  inline constexpr float WELD_GATE_HYST_V   = 0.010f;
  inline constexpr float WELD_DISCH_EPS_V   = 0.010f;

  inline constexpr bool  TRIG_PB4_ACTIVE_LOW   = true;
  inline constexpr bool  AUTO_PB12_ACTIVE_HIGH = true;
}

// ===================== Schonendes Laden (vor Puls) =====================
namespace CFG::THROTTLE {
  inline constexpr float    PCT              = 0.99f;
  inline constexpr uint16_t STEP_COUNTS      = 1000;
  inline constexpr uint16_t RESTORE_COUNTS   = 1000;
  inline constexpr uint16_t STEP_DELAY_MS    = 0;
  inline constexpr uint16_t DWELL_PRE_MS     = 5;
  inline constexpr uint16_t DWELL_POST_MS    = 5;
}

// ===================== Balancer =====================
namespace CFG::BAL {
  inline constexpr float        TOL_V    = 0.01f;
  inline constexpr unsigned long MIN_MS   = 1000UL;
}

// ===================== EEPROM-Adressen =====================
namespace CFG::EE {
  inline constexpr int MAX_V          = 0;
  inline constexpr int MIN_V          = 4;
  inline constexpr int P1_MS          = 8;   // byte
  inline constexpr int P2_MS          = 12;  // byte
  inline constexpr int MODE           = 16;
  inline constexpr int TEMPWARN_C     = 20;
  inline constexpr int AUTOPULSE_S    = 24;
  inline constexpr int ZIELSTROM_A    = 28;
  inline constexpr int START_DELAY_S  = 32;
  inline constexpr int RESUME_HYST_V  = 36;
  inline constexpr int ZIELLEISTUNG_W = 40;
  inline constexpr int WELDV_V        = 44;
  inline constexpr int I_OFFSET_MV    = 48;
  inline constexpr int I_GAIN         = 52;
  inline constexpr int WELDCOUNT      = 56;
}

// ===================== Kopfzeile & Stoppuhr =====================
namespace CFG::TOPBAR {
  // „Batterie“-Gauges
  inline constexpr int CAP_W = 47, CAP_H = 11, BORDER = 2;
  inline constexpr int CAP1_X = 6,  CAP1_Y = 0;
  inline constexpr int CAP2_X = 64, CAP2_Y = 0;

  // Summe („V“)
  inline constexpr int SUM_X = 39,  SUM_Y = 12, SUM_W = 45, SUM_H = 10;

  // Statusfeld rechts
  inline constexpr int STAT_X = 120, STAT_Y = 0, STAT_W = 50, STAT_H = 10;

  // Text-Baselines
  inline constexpr int YADJ_TOP   = 7;
  inline constexpr int YADJ_SUM   = 7;
}

namespace CFG::STOPWATCH {
  inline constexpr int GAP_ABOVE_P1 = 2;   // Abstand über P1
  inline constexpr int HEIGHT       = 15;  // Basis (160x)
  inline constexpr bool RESUME_AFTER_SETTINGS = true;
}

// ===================== Kachel-Geometrie & Typografie =====================
// Jede Kachel: Geometrie + Fonts + Größen + Offsets (Basis-Koords 160x128)
#include <Fonts/FreeSans9pt7b.h>
#include <Fonts/FreeSansBold9pt7b.h>

namespace CFG::FONT {
  inline const GFXfont* VAL    = &FreeSansBold9pt7b;
  inline const GFXfont* UNIT   = &FreeSans9pt7b;
  inline const GFXfont* STAT   = &FreeSansBold9pt7b;
  inline const GFXfont* LABEL  = &FreeSans9pt7b;
}

struct Typo {
  const GFXfont* labelFont; uint8_t labelSize; int labelDx; int labelDy;
  const GFXfont* valFont;   uint8_t valSize;   int valDx;   int valDy;
  const GFXfont* unitFont;  uint8_t unitSize;  int unitDx;  int unitDy;
};

struct Tile {
  // Geometrie
  int x, y, w, h;
  // Farben
  uint16_t fillColor;
  // Text-Layout
  Typo typo;
};

// obere Reihe: P1, P2, Auto (mit „Trim“)
inline constexpr int TOP_TRIM_PX = 24; // wie im Code

namespace CFG::TILES {
  // P1
  inline const Tile P1 {
    .x=2, .y=30 + (int)lroundf(TOP_TRIM_PX/1.875f), .w=50, .h=45 - (int)lroundf(TOP_TRIM_PX/1.875f),
    .fillColor=ST77XX_P1_GREEN,
    .typo={ FONT::LABEL,1, 5, 5,   FONT::VAL,1, 5, 0,    FONT::UNIT,1, 4, 0 }
  };
  // P2
  inline const Tile P2 {
    .x=54, .y=30 + (int)lroundf(TOP_TRIM_PX/1.875f), .w=50, .h=45 - (int)lroundf(TOP_TRIM_PX/1.875f),
    .fillColor=ST77XX_ORANGE,
    .typo={ FONT::LABEL,1, 5, 5,   FONT::VAL,1, 5, 0,    FONT::UNIT,1, 4, 0 }
  };
  // Auto
  inline const Tile AUTO {
    .x=106, .y=30 + (int)lroundf(TOP_TRIM_PX/1.875f), .w=50, .h=45 - (int)lroundf(TOP_TRIM_PX/1.875f),
    .fillColor=ST77XX_AUTO_TEAL,
    .typo={ FONT::LABEL,1, 5, 5,   FONT::VAL,1, 5, 0,    FONT::UNIT,1, 4, 0 }
  };
  // Strom
  inline const Tile STROM {
    .x=2, .y=77, .w=39, .h=45,
    .fillColor=ST77XX_PURPLE,
    .typo={ FONT::LABEL,1, 5, 5,   FONT::VAL,1, 5, 22,   FONT::UNIT,1, 4, 22 }
  };
  // Temp
  inline const Tile TEMP {
    .x=43, .y=77, .w=38, .h=45,
    .fillColor=ST77XX_RED,
    .typo={ FONT::LABEL,1, 5, 6,   FONT::VAL,1, 0, 18,   FONT::UNIT,1, 0, 18 }
  };
  // Weld V
  inline const Tile WELDV {
    .x=83, .y=77, .w=36, .h=45,
    .fillColor=ST77XX_DARKGREY,
    .typo={ FONT::LABEL,1, 5, 6,   FONT::VAL,1, 5, 25,   FONT::UNIT,1, 4, 25 }
  };
  // Einstellungen
  inline const Tile SETTINGS {
    .x=121, .y=77, .w=36, .h=45,
    .fillColor=ST77XX_SETTINGS_PURPLE,
    .typo={ FONT::LABEL,1, 5, 20,  FONT::VAL,1, 0, 0,    FONT::UNIT,1, 0, 0 }
  };
}

// ===================== Text-Helfer =====================
namespace CFG::TXT {
  // zentrale Textausgabe mit Font/Size/Color (Basis-Koords)
  template <typename Tft>
  inline void print(Tft& tft, const String& s, const GFXfont* f, uint8_t size,
                    int x, int y, uint16_t color) {
    tft.setFont(f);
    tft.setTextSize(size);
    tft.setTextColor(color);
    tft.setCursor(CFG::SX(x), CFG::SY(y));
    tft.print(s);
    tft.setFont(nullptr);
  }

  template <typename Tft>
  inline uint16_t textWidthPx(Tft& tft, const String& s, const GFXfont* f, uint8_t size){
    int16_t x1,y1; uint16_t w,h;
    tft.setFont(f);
    tft.setTextSize(size);
    tft.getTextBounds(s, 0, 0, &x1, &y1, &w, &h);
    return w;
  }
}
